
let number = Math.cbrt(27);
console.log(`Cube Root of 27 = ${number}`);